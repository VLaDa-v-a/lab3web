package com.github.dolphin.monitoring;

public interface AreaCalculatorMBean {
    void calculateArea(double r);
    double getArea();
}
