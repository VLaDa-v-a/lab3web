package com.github.dolphin.monitoring;


import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

@Named("areaCalculator")
@ApplicationScoped
public class AreaCalculator implements AreaCalculatorMBean {
    private double area;

    public double getArea() {
        return area;
    }

    @Override 
    public void calculateArea(double r) {
        area = ((Math.sqrt(3) * Math.pow(r, 2)) / 4) + (Math.pow(r, 2)) + ((Math.PI * Math.pow(r, 2)) / 4);
    }
}
